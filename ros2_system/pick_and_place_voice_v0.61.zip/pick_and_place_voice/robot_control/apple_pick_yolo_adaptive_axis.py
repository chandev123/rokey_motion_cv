#!/usr/bin/env python3
import time
import cv2
import numpy as np
import rclpy
from rclpy.node import Node
from scipy.spatial.transform import Rotation

# from realsense import ImgNode
# from onrobot import RG

import DR_init

# -----------------------------
# User parameters
# -----------------------------
ROBOT_ID = "dsr01"
ROBOT_MODEL = "m0609"
VELOCITY, ACC = 60, 60

DR_BASE = 0
DR_MV_MOD_REL = 1

GRIPPER_NAME = "rg2"
TOOLCHARGER_IP = "192.168.1.1"
TOOLCHARGER_PORT = "502"

MODEL_PATH = "yolo11n.pt"
TARGET_NAME = "banana"

CONF_THRES = 0.45
DETECT_HOLD_SEC = 2.0                    # "2초 이상 감지" 조건
MAX_GAP_SEC = 0.35                       # 프레임 누락/미검출 허용 간격(넘으면 리셋)

# pick motion tuning (mm)
# ※ 이제 "Z축" 고정이 아니라, 선택된 접근축(x/y/z) 방향으로 적용됩니다.
PREAPPROACH_DIST = 80                    # 대상에서 멀리 떨어진 프리어프로치 오프셋
PICK_PUSH_DIST  = 25                    # 최종 집기 시 대상 쪽으로 더 밀어주는 거리(기존 z - PICK_DZ 의미)
RETREAT_DIST    = 120                    # 집은 뒤 반대 방향으로 빠지는 거리
GRIP_WAIT = 0.7

# (선택) 접근 전에 현재 위치에서 안전하게 위로 살짝 올림 (base +Z 방향)
SAFE_LIFT_Z = 60                         # 0이면 비활성

# 카메라 정렬로 접근축을 고를 때, 축 정렬 신뢰도 임계값 (0~1)
CAM_ALIGN_TH = 0.75

# -----------------------------
# Doosan init
# -----------------------------
DR_init.__dsr__id = ROBOT_ID
DR_init.__dsr__model = ROBOT_MODEL


def clamp(v, lo, hi):
    return max(lo, min(hi, v))


# -----------------------------
# Module-Level Helper Functions (Pure Logic)
# -----------------------------

def get_robot_pose_matrix(x, y, z, rx, ry, rz):
    R = Rotation.from_euler("ZYZ", [rx, ry, rz], degrees=True).as_matrix()
    T = np.eye(4)
    T[:3, :3] = R
    T[:3, 3] = [x, y, z]
    return T

def axis_unit(axis, sign):
    if axis == "x":
        return np.array([float(sign), 0.0, 0.0])
    if axis == "y":
        return np.array([0.0, float(sign), 0.0])
    if axis == "z":
        return np.array([0.0, 0.0, float(sign)])
    raise ValueError(f"invalid axis: {axis}")

def infer_approach_axis_from_camera(base2cam):
    """
    카메라의 +Z(전방/깊이) 축이 base 좌표계의 어떤 축(x/y/z)과 가장 정렬되어 있는지 추정.
    """
    R = base2cam[:3, :3]

    # Camera forward axis: +Z in camera coordinates
    v_base = R @ np.array([0.0, 0.0, 1.0])

    idx = int(np.argmax(np.abs(v_base)))
    axis = ["x", "y", "z"][idx]
    sign = 1 if v_base[idx] >= 0 else -1
    confidence = float(abs(v_base[idx]))
    return axis, sign, confidence, v_base

def choose_approach_axis(base_xyz, current_pos, base2cam, logger=None):
    """
    1) 카메라 정렬(카메라 전방축)로 접근축 결정
    2) 정렬이 애매하면(conf 낮음) 현재 TCP->타깃 벡터의 가장 큰 성분축으로 fallback
    """
    axis, sign, conf, v_base = infer_approach_axis_from_camera(base2cam)

    if conf >= CAM_ALIGN_TH:
        if logger:
            logger.info(
                f"Approach axis from camera: axis={axis} sign={sign} conf={conf:.2f} v_base={v_base}"
            )
        return axis, sign, conf, "camera"

    # fallback: dominant delta axis from current TCP to target
    tcp_xyz = np.array(current_pos[:3], dtype=float)
    tgt = np.array(base_xyz[:3], dtype=float)
    d = tgt - tcp_xyz
    idx = int(np.argmax(np.abs(d)))
    axis2 = ["x", "y", "z"][idx]
    sign2 = 1 if d[idx] >= 0 else -1
    conf2 = float(abs(d[idx]) / (np.linalg.norm(d) + 1e-9))  # relative dominance
    
    if logger:
        logger.info(
            f"Approach axis fallback(dominant delta): axis={axis2} sign={sign2} conf~={conf2:.2f} "
            f"delta={d} (camera_conf={conf:.2f} < {CAM_ALIGN_TH})"
        )
    return axis2, sign2, conf2, "delta"


class ApplePickNode(Node):
    def __init__(self):
        super().__init__("apple_pick_node")

        # Camera node (your realsense.py)
        self.img_node = ImgNode()
        rclpy.spin_once(self.img_node)
        time.sleep(1.0)

        self.intrinsics = self.img_node.get_camera_intrinsic()
        if self.intrinsics is None:
            self.get_logger().warn("Camera intrinsics not received yet. Waiting a bit...")
            for _ in range(30):
                rclpy.spin_once(self.img_node)
                time.sleep(0.05)
                self.intrinsics = self.img_node.get_camera_intrinsic()
                if self.intrinsics is not None:
                    break
        if self.intrinsics is None:
            raise RuntimeError("No camera intrinsics. Check /camera/camera/color/camera_info topic.")

        # Hand-eye matrix
        # NOTE: code assumes this is T_gripper->camera (base2cam = base2gripper @ gripper2cam)
        self.gripper2cam = np.load("T_gripper2camera.npy")

        # Gripper
        self.gripper = RG(GRIPPER_NAME, TOOLCHARGER_IP, TOOLCHARGER_PORT)
        try:
            self.gripper.open_gripper()
        except Exception as e:
            self.get_logger().warn(f"gripper open failed (ignored): {e}")

        # YOLO
        from ultralytics import YOLO
        self.model = YOLO(MODEL_PATH)
        self.names = self.model.names  # id -> name

        self.apple_class_ids = [i for i, n in self.names.items() if n == TARGET_NAME]
        if not self.apple_class_ids:
            raise RuntimeError(f'YOLO model has no class named "{TARGET_NAME}". names={self.names}')
        self.apple_class_id = int(self.apple_class_ids[0])

        # Detection hold state
        self.hold_start_t = None
        self.last_seen_t = None
        self.last_center = None  # (cx, cy)

        self.get_logger().info(f"Ready. Holding condition: {TARGET_NAME} >= {DETECT_HOLD_SEC:.1f}s")

    # ---- geometry helpers (Delegated) ----
    def get_camera_pos(self, center_x, center_y, center_z, intrinsics):
        camera_x = (center_x - intrinsics["ppx"]) * center_z / intrinsics["fx"]
        camera_y = (center_y - intrinsics["ppy"]) * center_z / intrinsics["fy"]
        camera_z = center_z
        return (camera_x, camera_y, camera_z)

    def get_base2cam(self):
        """Returns T_base->camera using current TCP pose + hand-eye."""
        base2gripper = get_robot_pose_matrix(*get_current_posx()[0])
        return base2gripper @ self.gripper2cam

    def transform_to_base(self, camera_coords):
        coord = np.append(np.array(camera_coords), 1)  # Homogeneous coordinate
        base2cam = self.get_base2cam()
        td_coord = np.dot(base2cam, coord)
        return td_coord[:3]

    def get_depth_value(self, x, y, depth_frame):
        h, w = depth_frame.shape
        if 0 <= x < w and 0 <= y < h:
            return depth_frame[y, x]
        return None

    # ---- approach axis inference (Delegated) ----
    def infer_approach_axis_from_camera(self):
        return infer_approach_axis_from_camera(self.get_base2cam())

    def choose_approach_axis(self, target_xyz):
        current_pos = get_current_posx()[0]
        base2cam = self.get_base2cam()
        return choose_approach_axis(target_xyz, current_pos, base2cam, self.get_logger())

    @staticmethod
    def axis_unit(axis, sign):
        return axis_unit(axis, sign)

    # ---- robot action ----
    def pick_sequence(self, target_xyz, approach_axis, approach_sign):
        """
        target_xyz: base frame position (mm)
        approach_axis/sign: 선택된 접근축과 방향
          - 예) 카메라가 위에서 아래(-z)로 보고 있으면 approach_axis='z', approach_sign=-1
          - 예) 카메라가 +x 방향으로 보고 있으면 approach_axis='x', approach_sign=+1
        """
        # movej([0.0, 0.0, 0.0, 0.0, 0.0, -30.0], vel=VELOCITY, acc=ACC, 
        #       mod=DR_MV_MOD_REL)
        current_pos = get_current_posx()[0]
        rx, ry, rz = current_pos[3], current_pos[4], current_pos[5]

        tgt = np.array(target_xyz[:3], dtype=float)
        a = self.axis_unit(approach_axis, approach_sign)  # toward-object direction

        # (선택) 먼저 살짝 위로 안전 리프트
        # if SAFE_LIFT_Z and SAFE_LIFT_Z > 0:
        #     lift = posx([float(current_pos[0]), float(current_pos[1]), float(current_pos[2] + SAFE_LIFT_Z), rx, ry, rz])
        #     movel(lift, vel=VELOCITY, acc=ACC)

        pre_xyz     = tgt - a * PREAPPROACH_DIST
        pick_xyz    = tgt + a * PICK_PUSH_DIST
        retreat_xyz = tgt - a * RETREAT_DIST

        pre     = posx([float(pre_xyz[0]),     float(pre_xyz[1]),     float(pre_xyz[2]),     rx, ry, rz])
        pick    = posx([float(pick_xyz[0]),    float(pick_xyz[1]),    float(pick_xyz[2]),    rx, ry, rz])
        retreat = posx([float(retreat_xyz[0]), float(retreat_xyz[1]), float(retreat_xyz[2]), rx, ry, rz])

        self.get_logger().info(
            f"Pick sequence: axis={approach_axis} sign={approach_sign} "
            f"pre={pre_xyz.tolist()} pick={pick_xyz.tolist()} retreat={retreat_xyz.tolist()}"
        )

        # Approach -> Push -> Grip -> Retreat
        
        movel(pre, vel=VELOCITY, acc=ACC)
        movel(pick, vel=VELOCITY, acc=ACC)

        self.gripper.close_gripper()
        wait(GRIP_WAIT)

        movel(retreat, vel=VELOCITY, acc=ACC)

        # drop (원래 코드 유지)
        wait(GRIP_WAIT)
        movej([0, 0, 90, 0, 90, 0], vel=VELOCITY, acc=ACC)
        self.gripper.open_gripper()
        wait(GRIP_WAIT)



    # ---- main loop step ----
    def step(self):
        rclpy.spin_once(self.img_node, timeout_sec=0.0)

        img = self.img_node.get_color_frame()
        depth = self.img_node.get_depth_frame()
        if img is None or depth is None:
            return None

        # YOLO inference
        results = self.model.predict(img, conf=CONF_THRES, verbose=False)
        if not results:
            return img

        r = results[0]
        best = None  # (conf, (x1,y1,x2,y2))
        if r.boxes is not None and len(r.boxes) > 0:
            for b in r.boxes:
                cls = int(b.cls.item())
                if cls != self.apple_class_id:
                    continue
                conf = float(b.conf.item())
                x1, y1, x2, y2 = [float(v) for v in b.xyxy[0].tolist()]
                if best is None or conf > best[0]:
                    best = (conf, (x1, y1, x2, y2))

        now = time.monotonic()

        if best is None:
            # not seen -> reset if gap too large
            if self.last_seen_t is not None and (now - self.last_seen_t) > MAX_GAP_SEC:
                self.hold_start_t = None
                self.last_seen_t = None
                self.last_center = None
            return img

        conf, (x1, y1, x2, y2) = best
        cx = int((x1 + x2) / 2.0)
        cy = int((y1 + y2) / 2.0)

        # draw bbox
        cv2.rectangle(img, (int(x1), int(y1)), (int(x2), int(y2)), (0, 255, 0), 2)
        cv2.circle(img, (cx, cy), 4, (0, 0, 255), -1)

        # hold logic
        if self.last_seen_t is None or (now - self.last_seen_t) > MAX_GAP_SEC:
            self.hold_start_t = now
        self.last_seen_t = now
        self.last_center = (cx, cy)

        held = now - (self.hold_start_t or now)
        cv2.putText(img, f"{TARGET_NAME} conf={conf:.2f} hold={held:.2f}s",
                    (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (255, 255, 255), 2)



        # trigger
        if held >= DETECT_HOLD_SEC:
            # get depth at center (retry a bit if invalid)
            z = self.get_depth_value(cx, cy, depth)
            retry = 0
            while (z is None or z == 0) and retry < 10:
                rclpy.spin_once(self.img_node, timeout_sec=0.0)
                depth = self.img_node.get_depth_frame()
                if depth is not None:
                    z = self.get_depth_value(cx, cy, depth)
                retry += 1
                time.sleep(0.03)

            if z is None or z == 0:
                self.get_logger().warn("Depth invalid. Skipping this trigger.")
                self.hold_start_t = None
                self.last_seen_t = None
                self.last_center = None
                return img

            # If depth topic is meters (float) instead of mm, convert
            z_val = float(z)
            if z_val < 10.0:  # heuristic: likely meters
                z_val *= 1000.0

            cam_pos = self.get_camera_pos(cx, cy, z_val, self.intrinsics)
            base_xyz = self.transform_to_base(cam_pos)

            # 접근축 결정 (카메라 정렬 기반)
            axis, sign, conf2, method = self.choose_approach_axis(base_xyz)

            self.get_logger().info(
                f"TRIGGER: {TARGET_NAME} held {held:.2f}s -> pixel=({cx},{cy}) depth={z_val:.1f} "
                f"-> base={base_xyz} -> approach={axis}{'+' if sign > 0 else '-'} (by {method})"
            )

            # reset hold state BEFORE moving (so after motion it can detect again)
            self.hold_start_t = None
            self.last_seen_t = None
            self.last_center = None

            # perform pick
            self.pick_sequence(base_xyz, axis, sign)

        return img




if __name__ == "__main__":
    rclpy.init()

    # Doosan node init (same pattern as your test.py)
    node = rclpy.create_node("dsr_example_demo_py", namespace=ROBOT_ID)
    DR_init.__dsr__node = node

    try:
        from DSR_ROBOT2 import get_current_posx, movej, movel, wait
        from DR_common2 import posx, posj
    except ImportError as e:
        print(f"Error importing DSR_ROBOT2 : {e}")
        raise

    cv2.namedWindow("Webcam", cv2.WINDOW_NORMAL)

    app = ApplePickNode()

    while True:
        frame = app.step()
        if frame is not None:
            cv2.imshow("Webcam", frame)
        key = cv2.waitKey(1) & 0xFF
        if key == 27:  # ESC
            break

    cv2.destroyAllWindows()
    rclpy.shutdown()

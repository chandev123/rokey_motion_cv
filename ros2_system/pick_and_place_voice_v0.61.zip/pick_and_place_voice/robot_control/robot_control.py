import os
import time
import sys
from scipy.spatial.transform import Rotation
import numpy as np
import rclpy
from rclpy.node import Node
import DR_init

from od_msg.srv import SrvDepthPosition
from std_srvs.srv import Trigger
from ament_index_python.packages import get_package_share_directory
from robot_control.onrobot import RG
from .fridge_rightdown_open import do_fridge_rightdown_open
from .fridge_rightdown_close import do_fridge_rightdown_close
from .fridge_rightup_open import do_fridge_rightup_open
from .fridge_rightup_close import do_fridge_rightup_close
from .fridge_leftdown_open import do_fridge_leftdown_open
from .fridge_leftdown_close import do_fridge_leftdown_close
from .fridge_leftup_open import do_fridge_leftup_open
from .fridge_leftup_close import do_fridge_leftup_close
# from .apple_pick_yolo_adaptive_axis import ApplePickNode

# -----------------------------
# Import the pure math functions
# -----------------------------
try:
    from .apple_pick_yolo_adaptive_axis import axis_unit, choose_approach_axis
except ImportError as e:
    # Fallback if relative import fails or file is not in package yet
    import sys
    import os
    current_dir = os.path.dirname(os.path.abspath(__file__))
    if current_dir not in sys.path:
        sys.path.append(current_dir)
        
    # CRITICAL: apple_pick module needs 'realsense' from object_detection
    obj_det_path = os.path.normpath(os.path.join(current_dir, '../object_detection'))
    if obj_det_path not in sys.path:
        sys.path.append(obj_det_path)
        
    from apple_pick_yolo_adaptive_axis import axis_unit, choose_approach_axis


# pick motion tuning (mm) - Copied from apple_pick script
PREAPPROACH_DIST = 80
PICK_PUSH_DIST  = 25
RETREAT_DIST    = 120
GRIP_WAIT = 0.7

package_path = get_package_share_directory("pick_and_place_voice")

# for single robot
ROBOT_ID = "dsr01"
ROBOT_MODEL = "m0609"
VELOCITY, ACC = 60, 60
# BUCKET_POS = [445.5, -242.6, 174.4, 156.4, 180.0, -112.5]
GRIPPER_NAME = "rg2"
TOOLCHARGER_IP = "192.168.1.1"
TOOLCHARGER_PORT = "502"
DEPTH_OFFSET = -5.0
MIN_DEPTH = 2.0

DR_init.__dsr__id = ROBOT_ID
DR_init.__dsr__model = ROBOT_MODEL

rclpy.init()
dsr_node = rclpy.create_node("robot_control_node", namespace=ROBOT_ID)
DR_init.__dsr__node = dsr_node

try:
    from DSR_ROBOT2 import movej, movel, get_current_posx, mwait, trans, posx, wait, DR_MV_MOD_REL
except ImportError as e:
    print(f"Error importing DSR_ROBOT2: {e}")
    sys.exit()

########### Gripper Setup. Do not modify this area ############

gripper = RG(GRIPPER_NAME, TOOLCHARGER_IP, TOOLCHARGER_PORT)


########### Robot Controller ############


class RobotController(Node):
    def __init__(self):
        super().__init__("pick_and_place")
        self.init_robot()

        self.get_position_client = self.create_client(
            SrvDepthPosition, "/get_3d_position"
        )
        while not self.get_position_client.wait_for_service(timeout_sec=3.0):
            self.get_logger().info("Waiting for get_depth_position service...")
        self.get_position_request = SrvDepthPosition.Request()

        self.get_keyword_client = self.create_client(Trigger, "/get_keyword")
        while not self.get_keyword_client.wait_for_service(timeout_sec=3.0):
            self.get_logger().info("Waiting for get_keyword service...")
        self.get_keyword_request = Trigger.Request()

    def get_robot_pose_matrix(self, x, y, z, rx, ry, rz):
        R = Rotation.from_euler("ZYZ", [rx, ry, rz], degrees=True).as_matrix()
        T = np.eye(4)
        T[:3, :3] = R
        T[:3, 3] = [x, y, z]
        return T

    def transform_to_base(self, camera_coords, gripper2cam_path, robot_pos):
        """
        Converts 3D coordinates from the camera coordinate system
        to the robot's base coordinate system.
        """
        gripper2cam = np.load(gripper2cam_path)
        coord = np.append(np.array(camera_coords), 1)  # Homogeneous coordinate

        x, y, z, rx, ry, rz = robot_pos
        base2gripper = self.get_robot_pose_matrix(x, y, z, rx, ry, rz)

        # 좌표 변환 (그리퍼 → 베이스)
        base2cam = base2gripper @ gripper2cam
        td_coord = np.dot(base2cam, coord)

        return td_coord[:3]

    def robot_control(self):
        target_list = []
        self.get_logger().info("call get_keyword service")
        self.get_logger().info("say 'Hello Rokey' and speak what you want to pick up")
        
        # 1. 음성 명령 대기
        get_keyword_future = self.get_keyword_client.call_async(self.get_keyword_request)
        rclpy.spin_until_future_complete(self, get_keyword_future)

        if get_keyword_future.result().success:
            get_keyword_result = get_keyword_future.result()
            target_list = get_keyword_result.message.split()
            self.get_logger().info(f"Target List: {target_list}")

            for target in target_list:
                # [Step 1] 냉장고 문 열기 (물체 종류와 상관없이 수행)
                self.get_logger().info("Opening the refrigerator...")
                do_fridge_rightdown_open(movej, movel, posx, wait, gripper)

                # [Step 2] 물체 감지 및 위치 파악
                self.get_logger().info(f"Detecting target: '{target}'")
                target_pos = self.get_target_pos(target)

                # [Step 3] 감지 결과에 따른 분기
                if target_pos is None:
                    # 감지 실패 시
                    self.get_logger().warn(f"Failed to detect '{target}'. Skipping...")
                    self.init_robot()
                    continue # 다음 타겟으로 넘어감
                
                # 감지 성공 시 (사과, 바나나 등 구분 없이 공통 로직 적용)
                else:
                    self.get_logger().info(f"Target '{target}' detected at {target_pos[:3]}. Executing Adaptive Logic.")
                    
                    try:
                        # ---------------------------------------------------------
                        # 1. 현재 로봇 상태 및 핸드아이 정보 로드
                        # ---------------------------------------------------------
                        gripper2cam_path = os.path.join(package_path, "resource", "T_gripper2camera.npy")
                        gripper2cam = np.load(gripper2cam_path)
                        
                        current_pos = get_current_posx()[0] # [x, y, z, rx, ry, rz]
                        
                        # ---------------------------------------------------------
                        # 2. 로봇 베이스 기준 카메라 변환 행렬(Base to Camera) 계산
                        # ---------------------------------------------------------
                        rx, ry, rz = current_pos[3], current_pos[4], current_pos[5]
                        R = Rotation.from_euler("ZYZ", [rx, ry, rz], degrees=True).as_matrix()
                        
                        # Base -> Gripper Matrix
                        base2gripper = np.eye(4)
                        base2gripper[:3, :3] = R
                        base2gripper[:3, 3] = current_pos[:3]
                        
                        # Base -> Camera Matrix
                        base2cam = base2gripper @ gripper2cam
                        
                        # ---------------------------------------------------------
                        # 3. 최적 접근 축(Approach Axis) 계산
                        # ---------------------------------------------------------
                        # (주의) choose_approach_axis 함수가 정의되어 있거나 import 되어 있어야 함
                        axis, sign, conf, method = choose_approach_axis(
                            target_pos, current_pos, base2cam, self.get_logger()
                        )
                        
                        self.get_logger().info(f"[{target}] Plan: Axis={axis}, Sign={sign} (Method: {method})")
                        
                        # ---------------------------------------------------------
                        # 4. 계산된 축으로 피킹 실행 (Adaptive Sequence)
                        # ---------------------------------------------------------
                        self.pick_sequence_adaptive(target_pos, axis, sign)

                    except Exception as e:
                        self.get_logger().error(f"Error during pick sequence for '{target}': {e}")
                    
                    # 작업 완료 후 초기화
                    finally:
                        self.init_robot()

        else:
            self.get_logger().warn(f"Get keyword failed: {get_keyword_result.message}")
            return

    def get_target_pos(self, target):
        self.get_position_request.target = target
        self.get_logger().info("call depth position service with object_detection node")
        get_position_future = self.get_position_client.call_async(
            self.get_position_request
        )
        rclpy.spin_until_future_complete(self, get_position_future)

        if get_position_future.result():
            result = get_position_future.result().depth_position.tolist()
            self.get_logger().info(f"Received depth position: {result}")
            if sum(result) == 0:
                self.get_logger().info("No target position")
                return None

            gripper2cam_path = os.path.join(
                package_path, "resource", "T_gripper2camera.npy"
            )
            robot_posx = get_current_posx()[0]
            td_coord = self.transform_to_base(result, gripper2cam_path, robot_posx)

            if td_coord[2] and sum(td_coord) != 0:
                td_coord[2] += DEPTH_OFFSET  # DEPTH_OFFSET
                td_coord[2] = max(td_coord[2], MIN_DEPTH)  # MIN_DEPTH: float = 2.0

            target_pos = list(td_coord[:3]) + robot_posx[3:]
        return target_pos

    def init_robot(self):
        JReady = [0, 0, 90, 0, 90, 0]
        movej(JReady, vel=VELOCITY, acc=ACC)
        gripper.open_gripper()
        mwait()

    
    def pick_sequence_adaptive(self, target_xyz, approach_axis, approach_sign):
        """
        Executes picking motion based on calculated axis.
        Re-implements logic from apple_pick's pick_sequence but uses local init/gripper.
        """
        movej([0.0, 0.0, 0.0, 0.0, 0.0, -30.0], vel=VELOCITY, acc=ACC, 
              mod=DR_MV_MOD_REL)
        current_pos = get_current_posx()[0]
        rx, ry, rz = current_pos[3], current_pos[4], current_pos[5]

        tgt = np.array(target_xyz[:3], dtype=float)
        a = axis_unit(approach_axis, approach_sign)  # Direction Vector

        pre_xyz     = tgt - a * PREAPPROACH_DIST
        pick_xyz    = tgt + a * PICK_PUSH_DIST
        retreat_xyz = tgt - a * RETREAT_DIST

        # Construct posx objects (using current rotation)
        pre     = posx([float(pre_xyz[0]),     float(pre_xyz[1]),     float(pre_xyz[2]),     rx, ry, rz])
        pick    = posx([float(pick_xyz[0]),    float(pick_xyz[1]),    float(pick_xyz[2]),    rx, ry, rz])
        retreat = posx([float(retreat_xyz[0]), float(retreat_xyz[1]), float(retreat_xyz[2]), rx, ry, rz])

        self.get_logger().info(f"Moving to Pre-approach: {pre}")
        movel(pre, vel=VELOCITY, acc=ACC)
        
        self.get_logger().info(f"Moving to Pick: {pick}")
        movel(pick, vel=VELOCITY, acc=ACC)
        mwait()

        self.get_logger().info("Closing Gripper")
        gripper.close_gripper()
        time.sleep(GRIP_WAIT)

        self.get_logger().info(f"Retreating: {retreat}")
        movel(retreat, vel=VELOCITY, acc=ACC)
        mwait()

    def pick_and_place_target(self, target_pos):
        movel(target_pos, vel=VELOCITY, acc=ACC)
        mwait()
        gripper.close_gripper()

        while gripper.get_status()[0]:
            time.sleep(0.5)
        mwait()

        gripper.open_gripper()
        while gripper.get_status()[0]:
            time.sleep(0.5)


def main(args=None):
    node = RobotController()
    while rclpy.ok():
        node.robot_control()
    rclpy.shutdown()
    node.destroy_node()


if __name__ == "__main__":
    main()

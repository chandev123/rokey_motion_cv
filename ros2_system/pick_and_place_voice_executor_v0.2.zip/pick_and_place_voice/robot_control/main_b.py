import rclpy
from rclpy.node import MultiThreadedExecutor
from pick_and_place_voice.robot_control import RobotController

def main(args=None):
    rclpy.init(args=args)
    node = RobotController()
    executor = MultiThreadedExecutor()
    executor.add_node(node)
    while rclpy.ok():
        executor.spin_once(timeout_sec=1.0)
        node.robot_control()
    rclpy.shutdown()
    node.destroy_node()

if __name__ == "__main__":
    main()
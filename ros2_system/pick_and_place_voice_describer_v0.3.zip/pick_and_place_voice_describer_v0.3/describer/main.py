import rclpy
from rclpy.executors import MultiThreadedExecutor

from describer.describer import Describer

def main(args=None):
    rclpy.init(args=args)
    node = Describer()
    executor = MultiThreadedExecutor()
    executor.add_node(node)
    try:
        executor.spin()
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()

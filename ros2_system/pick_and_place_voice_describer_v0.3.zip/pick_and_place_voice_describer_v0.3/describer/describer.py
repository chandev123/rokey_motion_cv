import rclpy
from rclpy.node import Node
from rclpy.callback_groups import ReentrantCallbackGroup
import time

from std_msgs.msg import String

class Describer(Node):
    def __init__(self):
        super().__init__('describer_node')
        self.subscription = self.create_subscription(
            String,
            '/cocooker_status',
            self.subscriber_callback1,
            10
        )
        self.subscription  # prevent unused variable warning

    def subscriber_callback1(self, msg):
        self.get_logger().info(f'robot_control: {msg.data}')

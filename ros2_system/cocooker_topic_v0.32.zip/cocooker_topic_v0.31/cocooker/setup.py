from setuptools import find_packages, setup

package_name = 'cocooker'

setup(
    name=package_name,
    version='0.0.0',
    packages=find_packages(exclude=['test'],
    include=[
        'cocooker',
        'pan',
        'ramen',
        'spoon']),
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='markch',
    maintainer_email='cocoffeechan09@gmail.com',
    description='TODO: Package description',
    license='TODO: License declaration',
    extras_require={
        'test': [
            'pytest',
        ],
    },
    entry_points={
        'console_scripts': [
            'cocooker = cocooker.object_detection_selector:main',
            'pan = pan.pick_and_place_pan_yolo:main',
        ],
    },
)

"""
객체 탐지 폴더 선택 및 실행 시스템
각 객체 폴더의 pick_and_place.py를 선택하여 실행할 수 있습니다.
"""

import os
import sys
import subprocess

class ObjectDetectionSelector:
    def __init__(self, base_path='.'):
        """
        base_path: 객체 폴더들이 있는 기본 경로
        """
        self.base_path = base_path
        self.objects = self.scan_object_folders()

    def scan_object_folders(self):
        """객체 폴더들을 스캔하여 목록 생성"""
        objects = {}
        
        if not os.path.exists(self.base_path):
            print(f"❌ 경로를 찾을 수 없습니다: {self.base_path}")
            return objects
        
        # 모든 하위 폴더 검색
        folders = [f for f in os.listdir(self.base_path) 
                  if os.path.isdir(os.path.join(self.base_path, f)) and not f.startswith('.')]
        
        num = 1
        for folder in sorted(folders):
            folder_path = os.path.join(self.base_path, folder)
            
            # pick_and_place_*_yolo.py 파일 찾기
            pick_and_place = None
            for file in os.listdir(folder_path):
                if file.startswith('pick_and_place_') and file.endswith('_yolo.py'):
                    pick_and_place = os.path.join(folder_path, file)
                    break
            
            best_pt = os.path.join(folder_path, 'best.pt')
            
            # pick_and_place 파일이 있는지 확인
            if pick_and_place and os.path.exists(pick_and_place):
                objects[num] = {
                    'name': folder,
                    'path': folder_path,
                    'pick_and_place': pick_and_place,
                    'pick_and_place_filename': os.path.basename(pick_and_place),
                    'has_best_pt': os.path.exists(best_pt),
                    'files': self.get_folder_files(folder_path)
                }
                num += 1
        
        return objects
    
    def get_folder_files(self, folder_path):
        """폴더 내 파일 목록 가져오기"""
        try:
            files = [f for f in os.listdir(folder_path) if os.path.isfile(os.path.join(folder_path, f))]
            return files
        except:
            return []
    
    def display_menu(self):
        """사용 가능한 객체 폴더 목록 출력"""
        print("\n" + "="*60)
        print("🤖 객체 Pick & Place 실행 시스템")
        print("="*60)
        
        if not self.objects:
            print("\n⚠️  객체 폴더를 찾을 수 없습니다.")
            print(f"경로: {os.path.abspath(self.base_path)}")
            print("\n각 객체 폴더에는 다음 파일들이 있어야 합니다:")
            print("  - pick_and_place_[객체명]_yolo.py (필수)")
            print("  - best.pt (선택)")
            print("  - onrobot.py, realsense.py, T_gripper2camera.npy 등")
            return
        
        for num, info in self.objects.items():
            print(f"\n[{num}] {info['name']}")
            print(f"    📁 경로: {info['path']}")
            print(f"    📄 실행파일: {info['pick_and_place_filename']}")
            print(f"    {'✅' if info['has_best_pt'] else '⚠️ '} best.pt: {'있음' if info['has_best_pt'] else '없음'}")
            print(f"    📄 파일 목록: {', '.join(info['files'][:5])}")
            if len(info['files']) > 5:
                print(f"                 ... 외 {len(info['files']) - 5}개")
        
        print("\n[0] 종료")
        print("="*60)

    def execute_pick_and_place(self, choice):
        """선택한 객체의 pick_and_place 파일 실행"""
        if choice not in self.objects:
            print("❌ 잘못된 선택입니다.")
            return
        
        obj_info = self.objects[choice]
        pick_and_place_filename = obj_info['pick_and_place_filename']
        
        print(f"\n🚀 '{obj_info['name']}' 객체의 Pick & Place 실행 중...")
        print(f"📁 경로: {obj_info['path']}")
        print(f"📄 실행 파일: {pick_and_place_filename}")
        print("-" * 60)
        
        try:
            # pick_and_place 파일 실행
            # 해당 폴더를 작업 디렉토리로 설정
            result = subprocess.run(
                [sys.executable, pick_and_place_filename],
                cwd=obj_info['path'],
                capture_output=False,
                text=True
            )
            
            if result.returncode == 0:
                print("\n✅ 실행 완료!")
            else:
                print(f"\n⚠️  프로그램이 종료 코드 {result.returncode}로 종료되었습니다.")
                
        except FileNotFoundError:
            print(f"❌ {pick_and_place_filename} 파일을 찾을 수 없습니다.")
        except Exception as e:
            print(f"❌ 실행 중 오류 발생: {e}")
    
    def run(self):
        """메인 실행 루프"""
        while True:
            self.display_menu()
            
            if not self.objects:
                print("\n프로그램을 종료합니다.")
                break
            
            try:
                choice = input("\n번호를 선택하세요: ").strip()
                
                if choice == '0':
                    print("\n👋 프로그램을 종료합니다.")
                    break
                
                choice = int(choice)
                self.execute_pick_and_place(choice)
                
                input("\n계속하려면 Enter를 누르세요...")
                
            except ValueError:
                print("❌ 숫자를 입력해주세요.")
            except KeyboardInterrupt:
                print("\n\n👋 프로그램을 종료합니다.")
                break
            except Exception as e:
                print(f"❌ 오류 발생: {e}")


if __name__ == "__main__":
    print("🎯 객체 Pick & Place 선택 시스템")
    print("📁 현재 디렉토리에서 객체 폴더를 검색합니다...\n")
    
    # 기본 경로는 현재 디렉토리, 필요시 변경 가능
    # 예: selector = ObjectDetectionSelector('/path/to/objects')
    selector = ObjectDetectionSelector('.')
    selector.run()

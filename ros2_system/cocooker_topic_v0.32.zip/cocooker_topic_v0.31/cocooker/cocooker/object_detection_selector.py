"""
객체 탐지 폴더 선택 및 실행 시스템
각 객체 폴더의 pick_and_place.py를 선택하여 실행할 수 있습니다.
"""

import rclpy
from rclpy.node import Node
from rclpy.executors import SingleThreadedExecutor
from std_msgs.msg import String
from od_msg.srv import SrvDepthPosition
import time

import os
import sys
import subprocess

class ObjectDetectionSelector(Node):
    def __init__(self, base_path='.'):
        super().__init__('object_detection_selector')
        self.publisher1 = self.create_publisher(String, "/cocooker_status_pan", 10)
        self.timer1 = self.create_timer(3.0, self.timer_callback1)
        """
        base_path: 객체 폴더들이 있는 기본 경로
        """
        self.base_path = base_path
        self.objects = self.scan_object_folders()

    def timer_callback1(self):
        msg = String()
        msg.data = "1"
        self.publisher1.publish(msg)
        self.get_logger().info("Publishing: %s" % msg.data)

    def scan_object_folders(self):
        """객체 폴더들을 스캔하여 목록 생성"""
        objects = {}
        
        if not os.path.exists(self.base_path):
            print(f"❌ 경로를 찾을 수 없습니다: {self.base_path}")
            return objects
        
        # 모든 하위 폴더 검색
        folders = [f for f in os.listdir(self.base_path) 
                  if os.path.isdir(os.path.join(self.base_path, f)) and not f.startswith('.')]
        
        num = 1
        for folder in sorted(folders):
            folder_path = os.path.join(self.base_path, folder)
            
            # pick_and_place_*_yolo.py 파일 찾기
            pick_and_place = None
            for file in os.listdir(folder_path):
                if file.startswith('pick_and_place_') and file.endswith('_yolo.py'):
                    pick_and_place = os.path.join(folder_path, file)
                    break
            
            best_pt = os.path.join(folder_path, 'best.pt')
            
            # pick_and_place 파일이 있는지 확인
            if pick_and_place and os.path.exists(pick_and_place):
                objects[num] = {
                    'name': folder,
                    'path': folder_path,
                    'pick_and_place': pick_and_place,
                    'pick_and_place_filename': os.path.basename(pick_and_place),
                    'has_best_pt': os.path.exists(best_pt),
                    'files': self.get_folder_files(folder_path)
                }
                num += 1
        
        return objects
    
    def get_folder_files(self, folder_path):
        """폴더 내 파일 목록 가져오기"""
        try:
            files = [f for f in os.listdir(folder_path) if os.path.isfile(os.path.join(folder_path, f))]
            return files
        except:
            return []
    
    def display_menu(self):
        """사용 가능한 객체 폴더 목록 출력"""
        print("\n" + "="*60)
        print("🤖 객체 Pick & Place 실행 시스템")
        print("="*60)
        
        if not self.objects:
            print("\n⚠️  객체 폴더를 찾을 수 없습니다.")
            print(f"경로: {os.path.abspath(self.base_path)}")
            print("\n각 객체 폴더에는 다음 파일들이 있어야 합니다:")
            print("  - pick_and_place_[객체명]_yolo.py (필수)")
            print("  - best.pt (선택)")
            print("  - onrobot.py, realsense.py, T_gripper2camera.npy 등")
            return
        
        for num, info in self.objects.items():
            print(f"\n[{num}] {info['name']}")
            print(f"    📁 경로: {info['path']}")
            print(f"    📄 실행파일: {info['pick_and_place_filename']}")
            print(f"    {'✅' if info['has_best_pt'] else '⚠️ '} best.pt: {'있음' if info['has_best_pt'] else '없음'}")
            print(f"    📄 파일 목록: {', '.join(info['files'][:5])}")
            if len(info['files']) > 5:
                print(f"                 ... 외 {len(info['files']) - 5}개")
        
        print("\n[0] 종료")
        print("="*60)

    def execute_pick_and_place(self, choice):
        """선택한 객체의 pick_and_place 파일 실행"""
        if choice not in self.objects:
            print("❌ 잘못된 선택입니다.")
            return
        
        obj_info = self.objects[choice]
        pick_and_place_filename = obj_info['pick_and_place_filename']
        
        print(f"\n🚀 '{obj_info['name']}' 객체의 Pick & Place 시작 명령 전송 중...")
        print(f"📁 경로: {obj_info['path']}")
        print(f"Topic: /cocooker_status_pan")
        print(f"Message: start_{obj_info['name']}")
        print("-" * 60)
        
        try:
            # ROS 2 토픽으로 시작 신호 전송
            msg = String()
            msg.data = f"start_{obj_info['name']}"
            self.publisher1.publish(msg)
            print(f"\n✅ 시작 신호 전송 완료: {msg.data}")
            
        except Exception as e:
            print(f"❌ 오류 발생: {e}")
    
    def run(self):
        """메인 실행 루프"""
        while True:
            self.display_menu()
            
            if not self.objects:
                print("\n프로그램을 종료합니다.")
                break
            
            try:
                choice = input("\n번호를 선택하세요: ").strip()
                
                if choice == '0':
                    print("\n👋 프로그램을 종료합니다.")
                    break
                
                choice = int(choice)
                self.execute_pick_and_place(choice)
                
                input("\n계속하려면 Enter를 누르세요...")
                
            except ValueError:
                print("❌ 숫자를 입력해주세요.")
            except KeyboardInterrupt:
                print("\n\n👋 프로그램을 종료합니다.")
                break
            except Exception as e:
                print(f"❌ 오류 발생: {e}")


def main(args=None):
    rclpy.init(args=args)
    # 절대 경로 명시
    node = ObjectDetectionSelector('/home/markch/cobot_ws/src/cocooker')

    try:
        # ROS 2 스피너를 별도 스레드로 실행 (타이머 작동을 위해)
        import threading
        spin_thread = threading.Thread(target=rclpy.spin, args=(node,), daemon=True)
        spin_thread.start()

        # 메뉴 루프 실행 (블로킹)
        node.run()
        
    except KeyboardInterrupt:
        print("\n\n👋 프로그램을 종료합니다.")
    finally:
        rclpy.shutdown()
        node.destroy_node()

if __name__ == "__main__":
    print("🎯 객체 Pick & Place 선택 시스템")
    print("📁 현재 디렉토리에서 객체 폴더를 검색합니다...\n")
    
    # 기본 경로는 절대 경로로 설정 (ros2 run 실행 시 경로 문제 해결)
    selector = ObjectDetectionSelector('/home/markch/cobot_ws/src/cocooker')
    
    # ROS 2 콜백(타이머 등)을 처리하기 위해 별도 스레드에서 spin 실행
    import threading
    spin_thread = threading.Thread(target=rclpy.spin, args=(selector,), daemon=True)
    spin_thread.start()
    
    # 메인 스레드에서는 사용자 입력 메뉴 실행
    selector.run()
    
    selector.destroy_node()
    rclpy.shutdown()

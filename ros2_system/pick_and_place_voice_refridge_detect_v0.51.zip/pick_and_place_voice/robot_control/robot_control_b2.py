import rclpy
from rclpy.node import Node
from rclpy.callback_groups import ReentrantCallbackGroup
from rclpy.executors import MultiThreadedExecutor

from od_msg.srv import SrvDepthPosition
from std_srvs.srv import Trigger
from std_msgs.msg import String

import DR_init
from ament_index_python.packages import get_package_share_directory
from robot_control.onrobot import RG

import os
import sys
import time
from scipy.spatial.transform import Rotation
import numpy as np
import threading
from .fridge_rightdown_open import do_fridge_rightdown_open
package_path = get_package_share_directory("pick_and_place_voice")

# for single robot
ROBOT_ID = "dsr01"
ROBOT_MODEL = "m0609"
VELOCITY, ACC = 60, 60
# BUCKET_POS = [445.5, -242.6, 174.4, 156.4, 180.0, -112.5]
GRIPPER_NAME = "rg2"
TOOLCHARGER_IP = "192.168.1.1"
TOOLCHARGER_PORT = "502"
### 기본
# DEPTH_OFFSET = -5.0
### B3 위치
# DEPTH_OFFSET = -2.0
### B2 위치
DEPTH_OFFSET = 0.0
MIN_DEPTH = 2.0

DR_init.__dsr__id = ROBOT_ID
DR_init.__dsr__model = ROBOT_MODEL

rclpy.init()
dsr_node = rclpy.create_node("robot_control_node", namespace=ROBOT_ID)
DR_init.__dsr__node = dsr_node

try:
    from DSR_ROBOT2 import movej, movel, get_current_posx, mwait, trans, posx, wait
except ImportError as e:
    print(f"Error importing DSR_ROBOT2: {e}")
    sys.exit()

########### Gripper Setup. Do not modify this area ############

gripper = RG(GRIPPER_NAME, TOOLCHARGER_IP, TOOLCHARGER_PORT)

########### Robot Controller ############

class RobotController(Node):
    def __init__(self):
        super().__init__("pick_and_place")
        self.init_robot()
        
        ###insert###
        self.callback_group = ReentrantCallbackGroup()
        self.publisher1 = self.create_publisher(
            String, "/cocooker_control_status", 10, 
            callback_group=self.callback_group)
        self.timer1 = self.create_timer(1.0, self.timer_callback1)
        ###insert_end###

        self.get_position_client = self.create_client(
            SrvDepthPosition, "/get_3d_position", callback_group=self.callback_group
        )
        while not self.get_position_client.wait_for_service(timeout_sec=3.0):
            self.get_logger().info("Waiting for get_depth_position service...")
        self.get_position_request = SrvDepthPosition.Request()

        self.get_keyword_client = self.create_client(
            Trigger, "/get_keyword", callback_group=self.callback_group)
        while not self.get_keyword_client.wait_for_service(timeout_sec=3.0):
            self.get_logger().info("Waiting for get_keyword service...")
        self.get_keyword_request = Trigger.Request()

    def timer_callback1(self):
        msg = String()
        msg.data = "Alive"
        self.publisher1.publish(msg)
        self.get_logger().info("Publishing: %s" % msg.data)

    def get_keyword_done_callback(self, future):
        get_keyword_result = future.result()
        if get_keyword_result.success:
            self.get_logger().info(f"{get_keyword_result.message}")
        else:
            self.get_logger().warn(f"{get_keyword_result.message}")

    def get_position_callback(self, future):
        get_position_response = future.result()
        if get_position_response.success:
            self.get_logger().info("Position: %s" % get_position_response.message)
        else:
            self.get_logger().warn("Failed to get position")

    def get_robot_pose_matrix(self, x, y, z, rx, ry, rz):
        R = Rotation.from_euler("ZYZ", [rx, ry, rz], degrees=True).as_matrix()
        T = np.eye(4)
        T[:3, :3] = R
        T[:3, 3] = [x, y, z]
        return T

    def transform_to_base(self, camera_coords, gripper2cam_path, robot_pos):
        """
        Converts 3D coordinates from the camera coordinate system
        to the robot's base coordinate system.
        """
        gripper2cam = np.load(gripper2cam_path)
        coord = np.append(np.array(camera_coords), 1)  # Homogeneous coordinate

        x, y, z, rx, ry, rz = robot_pos
        base2gripper = self.get_robot_pose_matrix(x, y, z, rx, ry, rz)

        # 좌표 변환 (그리퍼 → 베이스)
        base2cam = base2gripper @ gripper2cam
        td_coord = np.dot(base2cam, coord)

        return td_coord[:3]

    def robot_control(self):
        target_list = []
        self.get_logger().info("call get_keyword service")
        self.get_logger().info("say 'Hello Rokey' and speak what you want to pick up")
        get_keyword_future = self.get_keyword_client.call_async(self.get_keyword_request)
        # rclpy.spin_until_future_complete(self, get_keyword_future)
        ###insert###
        get_keyword_future.add_done_callback(self.get_keyword_done_callback)
        ###insert_end###

        # for target in target_list:
        #     # self.get_logger().info("1-0 error checker")
        #     do_motion_demo(movej, movel, posx, wait, gripper)
        #     # self.get_logger().info("1-1 error checker")
        #     target_pos = self.get_target_pos(target)
        #     # self.get_logger().info("1-2 error checker")
        #     if target_pos is None:
        #         self.get_logger().warn("No target position")
        #     else:
        #         self.get_logger().info(f"target position: {target_pos}")
        #         self.pick_and_place_target(target_pos)
        #         self.init_robot()

        while not get_keyword_future.done():
            time.sleep(0.1)

        if get_keyword_future.result().success:
            get_keyword_result = get_keyword_future.result()


            ##use_case_start
            # if get_keyword_result.message == "hammer":
            #     return
            ##use_case_end


            target_list = get_keyword_result.message.split()

            self.get_logger().info(f"Targets to pick: {target_list}")
            for target in target_list:
                # self.get_logger().info("1-0 error checker")
                do_fridge_rightdown_open(movej, movel, posx, wait, gripper)
                # self.get_logger().info("1-1 error checker")
                target_pos = self.get_target_pos(target)
                # self.get_logger().info("1-2 error checker")
                if target_pos is None:
                    self.get_logger().warn("No target position")
                else:
                    self.get_logger().info(f"target position: {target_pos}")
                    self.pick_and_place_target(target_pos)
                    self.init_robot()

        else:
            self.get_logger().warn(f"{get_keyword_result.message}")
            return

    def get_target_pos(self, target):
        self.get_position_request.target = target
        self.get_logger().info("call depth position service with object_detection node")
        get_position_future = self.get_position_client.call_async(
            self.get_position_request
        )
        # rclpy.spin_until_future_complete(self, get_position_future)
        ###insert###
        get_position_future.add_done_callback(self.get_position_callback)

        # self.get_logger().info("point1, after add_done_callback")
        ###insert_end###
        
        while not get_position_future.done():
            # self.get_logger().info("point2, while not get_position_future.done()")
            time.sleep(0.1)

        if get_position_future.result():
            result = get_position_future.result().depth_position.tolist()
            # self.get_logger().info("point3, after get_position_future.result()")
            self.get_logger().info(f"Received depth position: {result}")
            if sum(result) == 0:
                print("No target position")
                return None

            gripper2cam_path = os.path.join(
                package_path, "resource", "T_gripper2camera.npy"
            )
            robot_posx = get_current_posx()[0]
            td_coord = self.transform_to_base(result, gripper2cam_path, robot_posx)

            if td_coord[2] and sum(td_coord) != 0:
                td_coord[2] += DEPTH_OFFSET  # DEPTH_OFFSET
                td_coord[2] = max(td_coord[2], MIN_DEPTH)  # MIN_DEPTH: float = 2.0

            # td_coord[3] += 5
            # td_coord[4] += 5
            # td_coord[5] += 5

            target_pos = list(td_coord[:3]) + robot_posx[3:]
        return target_pos

    def init_robot(self):
        JReady = [0, 0, 90, 0, 90, 0]
        movej(JReady, vel=VELOCITY, acc=ACC)
        gripper.open_gripper()
        mwait()

    def pick_and_place_target(self, target_pos):
        movel(target_pos, vel=VELOCITY, acc=ACC)
        mwait()
        gripper.close_gripper()

        while gripper.get_status()[0]:
            time.sleep(0.5)
        mwait()

        gripper.open_gripper()
        while gripper.get_status()[0]:
            time.sleep(0.5)

def main(args=None):
    node = RobotController()

    executor = rclpy.executors.MultiThreadedExecutor()
    executor.add_node(node)
    
    # Run executor in a background thread to handle callbacks (timer, services)
    executor_thread = threading.Thread(target=executor.spin, daemon=True)
    executor_thread.start()

    try:
        while rclpy.ok():
            node.robot_control()
            time.sleep(1.0)
    except KeyboardInterrupt:
        node.get_logger().info("Shutting down node...")
    
    node.destroy_node()
    rclpy.shutdown()

if __name__ == "__main__":
    main()
